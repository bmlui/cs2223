public class InvalidInputException extends Exception{
}
