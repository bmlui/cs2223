public class Main {
    /* The original name of the game is Nim. It was solved by Charles L. Bouton in
    1901 and was a part of the 1940 New York World's Fair Westinghouse. */

    public static void main(String[] args) {
       Tournament t = new Tournament();
       t.startTournament();
    }

}
